const express = require("express");
const adminRouter = express.Router();

// Rutas del Admin:
// ...

module.exports = adminRouter;
