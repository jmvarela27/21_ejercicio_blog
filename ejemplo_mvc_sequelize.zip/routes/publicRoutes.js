const express = require("express");
const publicRouter = express.Router();

// Rutas del Públicas:
// ...

module.exports = publicRouter;
